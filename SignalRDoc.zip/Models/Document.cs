﻿namespace SignalRDoc.Models
{
    public class Document
    {
        public int Id { get; set; }

        public string Content { get; set; } = "";
    }
}
