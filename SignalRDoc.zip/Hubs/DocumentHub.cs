﻿using Microsoft.AspNetCore.SignalR;

namespace SignalRDoc.Hubs
{
    public class DocumentHub : Hub
    {
        public static Dictionary<string, string> ConnectedUsers = new();

        public async Task SendDocumentUpdate(string content)
        {
            var username = Context.User.Identity?.Name ?? "Bilinmeyen";
            await Clients.Others.SendAsync("ReceiveDocumentUpdate", content, username);
        }
        public override Task OnConnectedAsync()
        {
            var username = Context.User.Identity?.Name ?? "Bilinmeyen";
            ConnectedUsers[Context.ConnectionId] = username;

            Clients.All.SendAsync("UpdateUserList", ConnectedUsers.Values.ToList());
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(Exception? exception)
        {
            if (ConnectedUsers.ContainsKey(Context.ConnectionId))
                ConnectedUsers.Remove(Context.ConnectionId);

            Clients.All.SendAsync("UpdateUserList", ConnectedUsers.Values.ToList());
            return base.OnDisconnectedAsync(exception);
        }

        public async Task SendMousePosition(string userName, int x, int y)
        {
            await Clients.Others.SendAsync("ReceiveMousePosition", userName, x, y);
        }

    }

}
