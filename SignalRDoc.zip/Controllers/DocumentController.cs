﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SignalRDoc.Controllers
{
    [Authorize]
    public class DocumentController : Controller
    {
        public IActionResult Editor()
        {
            return View();
        }
    }
}
