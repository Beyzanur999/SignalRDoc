﻿const connection = new signalR.HubConnectionBuilder()
    .withUrl("/documentHub")
    .build();

const userName = "Kullanıcı " + Math.floor(Math.random() * 1000);

// Belge düzenleme
const documentArea = document.getElementById("documentArea");

// Cursor gösterici kapsayıcı
const cursorContainer = document.getElementById("cursorContainer");

// Mouse pozisyonları
document.addEventListener("mousemove", (event) => {
    debugger;
    const x = event.clientX;
    const y = event.clientY;
    connection.invoke("SendMousePosition", userName, x, y);
});

// Başkalarının mouse hareketlerini göster
connection.on("ReceiveMousePosition", (senderName, x, y) => {
    let cursor = document.getElementById("cursor-" + senderName);

    if (!cursor) {
        cursor = document.createElement("div");
        cursor.className = "cursor-indicator";
        cursor.id = "cursor-" + senderName;
        cursor.style.backgroundColor = getColorFromName(senderName);
        cursor.title = senderName;
        cursorContainer.appendChild(cursor);
    }

    cursor.style.left = x + "px";
    cursor.style.top = y + "px";
});

// Belge güncelleme gönderme
documentArea.addEventListener("input", () => {
    debugger;
    connection.invoke("SendDocumentUpdate", documentArea.value);
});

// Belge güncelleme alma
connection.on("ReceiveDocumentUpdate", (content, sender) => {
    debugger;
    documentArea.value = content;
    document.getElementById("updateInfo").innerText = `${sender} tarafından güncellendi.`;
});

// Kullanıcı listesi güncelleme
connection.on("UpdateUserList", (userList) => {
    debugger;
    const userListElement = document.getElementById("userList");
    userListElement.innerHTML = "";
    userList.forEach(user => {
        const li = document.createElement("li");
        li.innerText = user;
        userListElement.appendChild(li);
    });
});

// Bağlantıyı başlat
connection.start().then(() => {
    console.log("SignalR bağlantısı kuruldu.");
}).catch(err => console.error(err.toString()));

// Yardımcı fonksiyon: kullanıcı adına göre renk oluştur
function getColorFromName(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = hash % 360;
    return `hsl(${hue}, 70%, 70%)`;
}
